# Scrollbar Pagination * Responsive Image Gallery | CPC

A Pen created on CodePen.io. Original URL: [https://codepen.io/TheMOZZARELLA/pen/oNpMxyy](https://codepen.io/TheMOZZARELLA/pen/oNpMxyy).

Horizontal image gallery with the scrollbar styled as pagination. Hover effects on the images, full viewport responsivity and a separate view for mobile.